# parmidazinati.github.io

نسخه بازطراحی‌شده سایت شخصی پارمیدا زینتی و برند Quantum.

## انتشار روی GitHub Pages

محتویات این پوشه را در ریشه مخزن `parmidazinati.github.io` قرار دهید و commit/push کنید. فایل `index.html` صفحه اصلی است و پوشه `assets/` تصاویر بهینه‌شده را نگه می‌دارد.

تصاویر مفهومی بخش‌های تمرکز از Unsplash تهیه شده‌اند.
